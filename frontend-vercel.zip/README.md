# Lopes Designer - Frontend (Vercel)

Portfolio profissional de design gráfico e desenvolvimento web - Frontend React + Vite.

## 🚀 Deploy no Vercel

### Método 1: Via Interface do Vercel (Recomendado)

1. **Acesse** [vercel.com](https://vercel.com)
2. **Clique** em "Add New" → "Project"
3. **Importe** este repositório
4. **Configurações de Build:**
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`

5. **Variáveis de Ambiente:**
   - Vá em "Environment Variables"
   - Adicione: `VITE_API_URL` = `https://seu-backend.onrender.com`
   - **Importante:** Substitua pela URL real do seu backend no Render

6. **Clique** em "Deploy"

### Método 2: Via Vercel CLI

```bash
# Instalar Vercel CLI
npm install -g vercel

# Deploy
vercel

# Deploy para produção
vercel --prod
```

## 🛠️ Desenvolvimento Local

```bash
# Instalar dependências
npm install

# Criar arquivo .env com a URL do backend
echo "VITE_API_URL=http://localhost:5000" > .env

# Rodar servidor de desenvolvimento
npm run dev

# Build para produção
npm run build
```

## 📁 Estrutura do Projeto

```
frontend-vercel/
├── client/               # Código React
│   ├── public/          # Assets estáticos
│   └── src/             # Código fonte
│       ├── components/  # Componentes React
│       ├── pages/       # Páginas
│       ├── hooks/       # React hooks customizados
│       └── lib/         # Utilitários
├── shared/              # Tipos TypeScript compartilhados
├── attached_assets/     # Imagens e assets
├── data/                # Dados JSON (portfolio, services, etc.)
└── vite.config.ts       # Configuração do Vite
```

## 🎨 Stack Tecnológica

- **Framework:** React 18 + TypeScript
- **Build Tool:** Vite
- **UI Components:** Radix UI, shadcn/ui
- **Styling:** Tailwind CSS
- **Animations:** Framer Motion
- **Icons:** Lucide React
- **Forms:** React Hook Form + Zod
- **Routing:** Wouter

## ⚙️ Configurações Importantes

### Conectar ao Backend

1. Após fazer o deploy do backend no Render, você receberá uma URL como:
   - `https://lopes-designer-backend.onrender.com`

2. Adicione essa URL nas variáveis de ambiente do Vercel:
   - Nome: `VITE_API_URL`
   - Valor: `https://lopes-designer-backend.onrender.com`

3. Faça redeploy do frontend para aplicar a mudança

### Domínio Customizado

No Vercel dashboard:
1. Vá em "Settings" → "Domains"
2. Adicione seu domínio customizado
3. Configure os DNS conforme instruções do Vercel

## 🔧 Scripts Disponíveis

- `npm run dev` - Inicia servidor de desenvolvimento
- `npm run build` - Cria build de produção
- `npm run preview` - Preview do build de produção
- `npm run check` - Verifica tipos TypeScript

## 📝 Notas

- O frontend faz chamadas API para o backend para buscar dados dinâmicos
- Dados estáticos (portfolio, serviços, etc.) estão na pasta `data/`
- Imagens estão em `attached_assets/`
- A aplicação é uma SPA (Single Page Application) com client-side routing

## 🐛 Solução de Problemas

### Erro de CORS
Se você ver erros de CORS no console:
1. Verifique se o backend está configurado corretamente
2. Confirme que a URL do backend nas variáveis de ambiente está correta
3. Certifique-se de que o backend permite requisições do domínio do Vercel

### Build falha
1. Verifique se todas as dependências estão instaladas
2. Execute `npm run check` para verificar erros de TypeScript
3. Confirme que a variável `VITE_API_URL` está configurada

---

Desenvolvido com 💜 por Lopes Designer
